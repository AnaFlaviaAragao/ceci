#ifndef SUM_H
#define SUM_H
int somador(int a, int b, int *c);
#endif //SUM_H