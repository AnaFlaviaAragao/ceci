#include "inv_1_gm.hpp"

int inversor(int value)
{
    return !value;
}