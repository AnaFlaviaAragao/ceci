#ifndef INV_H
#define INV_H
int inversor(int value);
#endif //INV_H