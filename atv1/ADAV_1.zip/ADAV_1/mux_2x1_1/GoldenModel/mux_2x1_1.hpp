#ifndef MUX_H
#define MUX_H
int mux(int a, int b, int selector);
#endif //MUX_H