#ifndef FLOP_H
#define FLOP_H
int flop(int a, int b, int *c);
#endif //FLOP_H